package com.luisdornellez.radio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Muestra únicamente la página de la radio dentro de un WebView.
 * El reproductor es el de la propia página: la app no lo modifica ni lo reemplaza.
 */
public class MainActivity extends Activity {

    static final String EXTRA_EXIT = "exit";

    private static final String OFFLINE_URL = "file:///android_asset/offline.html";
    private static final String PREFS = "radio_prefs";
    private static final String KEY_BATT_ASKED = "batt_asked";
    private static final int REQ_NOTIF = 101;

    private final Handler main = new Handler(Looper.getMainLooper());

    private WebView webView;
    private View splash;
    private String radioUrl;
    private String baseHost;
    private boolean showingOffline = false;
    private ConnectivityManager.NetworkCallback netCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent() != null && getIntent().getBooleanExtra(EXTRA_EXIT, false)) {
            stopService(new Intent(this, RadioService.class));
            finishAndRemoveTask();
            return;
        }

        setContentView(R.layout.activity_main);
        radioUrl = getString(R.string.radio_url);
        String host = Uri.parse(radioUrl).getHost();
        if (host == null) host = "";
        baseHost = host.startsWith("www.") ? host.substring(4) : host;

        webView = findViewById(R.id.webView);
        splash = findViewById(R.id.splash);

        configureWebView();
        webView.loadUrl(radioUrl);

        registerNetworkCallback();
        startRadioService();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else {
            maybeAskBatteryExemption();
        }
    }

    private void configureWebView() {
        webView.setBackgroundColor(Color.parseColor("#0B1026"));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setUserAgentString(s.getUserAgentString() + " PalabrasDeEsperanzaApp/1.0");

        // Mantiene el proceso del reproductor con prioridad alta aunque la app no esté visible.
        if (Build.VERSION.SDK_INT >= 26) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if ("app".equals(scheme)) {
                    retry();
                    return true;
                }
                if (!request.isForMainFrame()) return false;
                if ("file".equals(scheme)) return false;
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if (isInternalHost(u.getHost())) return false;
                    openExternal(u);
                    return true;
                }
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplash();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showOffline();
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            WebResourceResponse errorResponse) {
                if (request.isForMainFrame() && errorResponse.getStatusCode() >= 400) showOffline();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          Message resultMsg) {
                // window.open(): los enlaces de compartir se abren fuera de la app.
                final WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                        openExternal(request.getUrl());
                        main.post(new Runnable() {
                            @Override
                            public void run() {
                                tmp.destroy();
                            }
                        });
                        return true;
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }
        });
    }

    private boolean isInternalHost(String host) {
        if (host == null || baseHost.isEmpty()) return false;
        return host.equals(baseHost) || host.endsWith("." + baseHost);
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
        }
    }

    private void showOffline() {
        if (showingOffline) return;
        showingOffline = true;
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.loadUrl(OFFLINE_URL);
            }
        });
    }

    private void retry() {
        showingOffline = false;
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.loadUrl(radioUrl);
            }
        });
    }

    private void hideSplash() {
        if (splash == null || splash.getVisibility() != View.VISIBLE) return;
        splash.animate().alpha(0f).setDuration(350).withEndAction(new Runnable() {
            @Override
            public void run() {
                splash.setVisibility(View.GONE);
            }
        }).start();
    }

    private void registerNetworkCallback() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            netCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    if (showingOffline) retry();
                }
            };
            cm.registerDefaultNetworkCallback(netCallback);
        } catch (RuntimeException e) {
            netCallback = null;
        }
    }

    private void startRadioService() {
        try {
            startForegroundService(new Intent(this, RadioService.class));
        } catch (RuntimeException ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            startRadioService(); // vuelve a publicar la notificación ya con permiso
            maybeAskBatteryExemption();
        }
    }

    private void maybeAskBatteryExemption() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) return;

            final SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            int asked = sp.getInt(KEY_BATT_ASKED, 0);
            if (asked >= 2) return;
            sp.edit().putInt(KEY_BATT_ASKED, asked + 1).apply();

            new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle(R.string.batt_title)
                    .setMessage(R.string.batt_msg)
                    .setCancelable(true)
                    .setPositiveButton(R.string.batt_ok, new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            requestIgnoreBatteryOptimizations();
                        }
                    })
                    .setNegativeButton(R.string.batt_later, null)
                    .show();
        } catch (RuntimeException ignored) {
        }
    }

    private void requestIgnoreBatteryOptimizations() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (RuntimeException e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (RuntimeException ignored) {
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(EXTRA_EXIT, false)) {
            exitApp();
        }
    }

    private void exitApp() {
        stopService(new Intent(this, RadioService.class));
        if (webView != null) webView.loadUrl("about:blank");
        finishAndRemoveTask();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && !showingOffline && webView.canGoBack()) {
            webView.goBack();
        } else {
            // No se cierra: pasa a segundo plano y la radio sigue sonando.
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onDestroy() {
        if (netCallback != null) {
            try {
                ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE))
                        .unregisterNetworkCallback(netCallback);
            } catch (RuntimeException ignored) {
            }
            netCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
