# 📻 Palabras de Esperanza — App Android

App que muestra **solo la radio** de la página (`https://www.poema.co.uk/radio/`).
No incluye ningún reproductor nuevo: usa el reproductor que ya tiene tu página, tal cual.

## Qué hace

- Pantalla completa con la página de la radio (con pantalla de carga premium).
- **Servicio en primer plano** con notificación "Radio en vivo" y botón **Salir**.
- Pide **desactivar la optimización de batería** para que Android no cierre la app.
- Bloqueos de CPU y Wi-Fi mientras la radio está activa.
- El botón Atrás no cierra la app: la pasa a segundo plano y la radio sigue sonando.
- Sin internet muestra una pantalla "Sin conexión" y se reconecta sola.
- Los enlaces de compartir (WhatsApp, Facebook, X) se abren fuera de la app.

## Cómo obtener el APK (todo en GitHub, sin instalar nada)

1. Crea un repositorio nuevo en GitHub (por ejemplo `radio-app`).
2. Sube **todo el contenido** de este zip, incluida la carpeta oculta `.github`.
3. Entra en la pestaña **Actions**. Verás "Construir APK" ejecutándose (tarda 3–6 min).
   Si no arranca: elige "Construir APK" → **Run workflow**.
4. Al terminar (✅ verde), abre esa ejecución y descarga **Palabras-de-Esperanza-APK** en *Artifacts*.
   Es un zip: descomprímelo y dentro está `Palabras-de-Esperanza.apk`.
5. Instálalo en el celular (acepta "instalar apps de origen desconocido" si lo pide).

### Opción con enlace de descarga directo
Crea una etiqueta (tag) que empiece con `v`, por ejemplo `v1.0.0`. El APK aparecerá en **Releases**.

### Subir desde el celular con Termux (recomendado por la carpeta `.github`)
La carpeta `.github` es oculta y la web de GitHub suele no mostrarla en el celular. Con Termux:

```bash
pkg install git unzip -y
unzip radio-apk-github.zip -d radio-app
cd radio-app
git init
git add -A
git commit -m "App de la radio"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/radio-app.git
git push -u origin main
```
(GitHub te pedirá usuario y un *token de acceso personal* como contraseña.)

## Para que Android NO cierre la radio (Poco / Xiaomi / HyperOS)

Al abrir la app por primera vez:
1. Acepta el permiso de **notificaciones**.
2. Pulsa **Permitir** en el aviso de batería.

En Xiaomi/Poco además, una sola vez:
- **Ajustes → Aplicaciones → Administrar aplicaciones → Palabras de Esperanza → Ahorro de batería → Sin restricciones.**
- Activa **Inicio automático**.
- En Recientes, mantén pulsada la tarjeta de la app y toca el **candado** 🔒.

## Cambiar cosas

| Qué | Dónde |
|---|---|
| Dirección de la radio | `app/src/main/res/values/strings.xml` → `radio_url` |
| Nombre de la app | `strings.xml` → `app_name` |
| Colores | `res/values/colors.xml` |
| Versión | `app/build.gradle` → `versionCode` / `versionName` |

## Notas importantes

- **Firma:** el APK se firma con `app/radio-release.jks`. Va incluida para que cada versión nueva se instale encima de la anterior sin desinstalar. Es una clave de uso personal; si publicas en Google Play, crea la tuya y no la compartas.
- **Reproductor:** la app carga tu página. Si la página cambia o cae, la app lo refleja. Para que el audio siga con la pantalla apagada, el reproductor de la página debe seguir usando `<audio>`/stream normal (no se modificó nada).
- **Salir:** usa el botón *Salir* de la notificación (o cierra la app desde Recientes) para detener la radio.
- Requiere Android 8.0 o superior.
